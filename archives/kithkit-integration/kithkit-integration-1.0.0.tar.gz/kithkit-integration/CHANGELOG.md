# Changelog

## 1.0.0 (2026-02-26)

- Initial release
- Foundation skill covering extension patterns, daemon API, scheduler, channel router, and memory system
- 12 integration recipes: Telegram, Graph email, Outlook IMAP, Himalaya email, JMAP email, email triage task, voice overview, voice client, voice STT, voice TTS, Browserbase, GitHub rate limiting
